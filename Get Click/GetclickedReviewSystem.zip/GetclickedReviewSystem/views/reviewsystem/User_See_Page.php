<?php
   global $wpdb;
    $GanetetedUrlIs = site_url()."/reviews/?review=".$_GET['review'];
    $results = $wpdb->get_results("SELECT * FROM `".TableName_ReviewSystem()."` WHERE `GeneratedLink` = \"".$GanetetedUrlIs."\"");
    print_r($results);
   
   ?>
