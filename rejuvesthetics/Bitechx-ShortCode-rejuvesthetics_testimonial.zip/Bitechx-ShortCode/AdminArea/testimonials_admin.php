<?php 
     global $wpdb;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Testimonials Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
</head>
<body>

<div class="container">
  <h1>
    Testimonials Information
    </h1> 
    <br><br>
    <div id = "TestimonialAddData">
    <h3>
    Testimonial Add Data
    
    
    </h3><br>
    
        <form action = "javascript:void(0)" id="TestimonialUpdateAdmin">
          <div class="form-group">
            <label for="exampleInputEmail1">User Name : </label>
            <input type="text" class="form-control" id="FirstName" name = "FirstName" placeholder="Enter First Name" required>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Date :</label>
            <input type="text" class="form-control" id="GivenDate" name = "GivenDate"  placeholder="Date" >
          </div>
           <div class="form-group">
            <label for="exampleInputPassword1">Location : </label>
            <input type="text" class="form-control" id="GivenLocation" name = "GivenLocation" placeholder="Location" >
          </div>
          <div class="form-group">
            <label for="exampleFormControlTextarea1">Testimonial : </label>
            <textarea class="form-control" id="TestimonialTextarea" name = "TestimonialTextarea" rows="3" required></textarea>
        </div>
          
          <button type="submit" class="btn btn-primary" id="addDataSubmitButton">Submit</button>
        </form>
        
        
        
 </div>       
        
        
        <br><br><br>
   <div id = "TestimonialSeeData">     
        <?php
        $array = $wpdb->get_results( "SELECT * FROM ".TableName_Testimonial());
        ?>
     <h3>
        
        Testimonial See Data
    
    
    </h3>   <br>
    
    
    
    
    <table id="table_id" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Date</th>
                <th>Location</th>
                <th>Testimonial</th>
                 <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            
            <?php 
            if(count($array) >= 0){ 
                foreach($array as $val){ 
        ?>
            
            <tr>
                <td><?php echo $val->id; ?></td>
                <td><?php echo $val->Fname; ?></td>
                <td><?php echo $val->Date; ?></td>
                <td><?php echo $val->Location; ?></td>
                <td><?php echo $val->Testimonial; ?></td>
<td><a href="#TestimonialEditData"> <button type="button" class="btn btn-primary" id="EditButton_<?php echo $val->id; ?>" value ="<?php echo $val->id; ?>">Edit</button>
                <td> <button type="button" class="btn btn-danger" id="DeleteButton_<?php echo $val->id; ?>" value ="<?php echo $val->id; ?>">Delete</button> </td>
            </tr>
            <script>
                 $('#EditButton_<?php echo $val->id; ?>').click(function(){
                 $("#IdSelect").val($(this).val()).change();
             })
                $('#DeleteButton_<?php echo $val->id; ?>').click(function(){
                    var conf = confirm("Are you sure to delete the testimonial ?");
                    if(conf){
                        $(this).attr("disabled", true);
                        var postValue = "action=TestimonialUpdateAdmin&parem=TestimonialUpdateAdminDelete_Data&DeletedId=<?php echo $val->id; ?>";
                        console.log(postValue);
                        var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
                        console.log(ajaxurl);
                            
                        jQuery.post(ajaxurl,postValue,function(response){
                                console.log(response);
            
                                var data = jQuery.parseJSON(response);
                                if (data.status == "success") {
                                    location.reload();
                                }
                                
                            }) ;
                    }
                  
                });
                
            </script>
             <?php
                }
            }
        ?>
        </tbody>
        
    </table>
    
    
 </div>   
    
    
    
    <br>
    
       <div id = "TestimonialEditData">   
     <h3>
        
        Testimonial Edit Data
        
        
    </h3><br>

    <form action = "javascript:void(0)" id="TestimonialUpdateEditDataAdmin">
      
      
      <div class="form-group">
        <label for="exampleInputEmail1">Select Id : </label>
        <select class="form-control" name="IdSelect" id="IdSelect">
            <option value="0">Default select</option>
            <?php 
                if(count($array) >= 0){ 
                    foreach($array as $val){ 
             ?>
                 <option value="<?php echo $val->id; ?>"> <?php echo $val->id; ?> </option>
                
                <?php
                }
            }
        ?>
        </select>
        
      </div>
      
      <div id = "EditShowData">
          
      
      
              <div class="form-group">
                <label for="exampleInputEmail1">User Name : </label>
                <input type="text" class="form-control" id="FirstNameEdit" name = "FirstNameEdit" placeholder="Enter First Name" required>
                
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1">Date  :</label>
                <input type="text" class="form-control" id="GivenDateEdit" name = "GivenDateEdit"  placeholder="Date" >
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1">Location : </label>
                <input type="text" class="form-control" id="GivenLocationEdit" name = "GivenLocationEdit" placeholder="Location">
              </div>
              <div class="form-group">
                <label for="exampleFormControlTextarea1">Testimonial : </label>
                <textarea class="form-control" id="TestimonialTextareaEdit" name = "TestimonialTextareaEdit" rows="3" required></textarea>
            </div>
              
              <button type="submit" class="btn btn-primary" id="EditDataSubmitButton">Edit</button>
      
      </div>
      
    </form>
    
    
</div>
    
    
    

  
  
</div>

</body>


<script>
    
     $(document).ready(function(){
         $("#EditShowData").hide();
         $('#table_id').DataTable();
         $("#TestimonialUpdateAdmin").validate({
                  submitHandler:function(){
                            $('#addDataSubmitButton').attr("disabled", true);
                            var postValue = "action=TestimonialUpdateAdmin&parem=TestimonialUpdateAdminAdd_Data&"+jQuery("#TestimonialUpdateAdmin").serialize();
                            console.log(postValue);
                            var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
                            console.log(ajaxurl);
                            
                           
                            jQuery.post(ajaxurl,postValue,function(response){
                                console.log(response);
            
                                var data = jQuery.parseJSON(response);
                                if (data.status == "success") {
                                    location.reload();
                                }
                                
                                
                            }) ;
            
            
            
                        }
                     
             
            });
            
            
            
            
             $("#IdSelect").change(function(){
                 $("#EditShowData").hide();
                if($(this).val() != 0){
                    
                     var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
                     var postValue = "action=TestimonialUpdateAdmin&parem=TestimonialUpdateAdminedit_Data&selectedId="+$(this).val();
                      $(this).attr("disabled", true);
                     jQuery.post(ajaxurl,postValue,function(response){
                                console.log(response);
                                $("#IdSelect").attr("disabled", false);
                                $("#EditShowData").show();
                                
                                var data = jQuery.parseJSON(response);
                                console.log(data);
                                if (data.status == "success") {
                                    var message = jQuery.parseJSON(data.message);
                                    
                                    
                                    
                                    var Fname = message[0].Fname;
                                    var date = message[0].Date;
                                    var location = message[0].Location;
                                    var testimonial = message[0].Testimonial;
                                    
                                     $("#FirstNameEdit").val(Fname);
                                      $("#GivenDateEdit").val(date); 
                                      $("#GivenLocationEdit").val(location);
                                       $("#TestimonialTextareaEdit").val(testimonial);
                                    
                                }
                            }) ;
                    
                    
                    
                    
                }
                else{
                    $("#EditShowData").hide();
                }
            });
            
            
            
             $("#TestimonialUpdateEditDataAdmin").validate({
                  submitHandler:function(){
                            $('#EditDataSubmitButton').attr("disabled", true);
                            var postValue = "action=TestimonialUpdateAdmin&parem=TestimonialUpdateAdminEditAdd_Data_form&"+jQuery("#TestimonialUpdateEditDataAdmin").serialize();
                            console.log(postValue);
                            var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
                            console.log(ajaxurl);
                            
                           
                            jQuery.post(ajaxurl,postValue,function(response){
                                console.log(response);
            
                                var data = jQuery.parseJSON(response);
                               
                                if (data.status == "success") {
                                    location.reload();
                                }
                                
                            }) ;
            
            
            
                        }
                     
                  
             
            });
            
         
     });
    
    
</script>

</html>
