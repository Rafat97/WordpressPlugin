<?php

//$var = do_shortcode( '[Btx_Show_Testimonial_Main_Page]' );
//echo $var;

?>





<!DOCTYPE html>
<html lang="en">
<head>
  <title>Testimonials Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
</head>
<body>


<h1>
    Short Code  Description
</h1> 
<br><br>
   




<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Short Code </th>
                <th>Description</th>
                <th>Editable File Path</th>
                
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>[Btx_Show_Testimonial_Main_Page]</td>
                <td>Testimonial show in his own page</td>
                <td>home2/rejuvest/public_html/wp-content/plugins/Bitechx-ShortCode/views/Main_Page_testimonial_show.php</td>
                
            </tr>
            
            
        </tbody>
        
    </table>
    
    
    
    
    
    
    
    
    
    
    
    </body>
    <script>
        
        $(document).ready(function() {
            $('#example').DataTable();
        } );
        
    </script>
</html>
