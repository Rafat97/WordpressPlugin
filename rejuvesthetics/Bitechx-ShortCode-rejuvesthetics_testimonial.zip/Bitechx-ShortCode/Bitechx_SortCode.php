<?php
/*
Plugin Name:  BiTechX Shortcode 
Plugin URI:   
Description:  Own Make Bitechx Shortcode For Rejuvesthetics
Version:      1.0.0
Author:       Rafat Haque
Author URI:   
*/
	
	
	if (!defined('ABSPATH')) {
		die;
	}
	if(!defined('WPINC')){
		die;
	}
	if(!defined("REJUVE_BITECHX_SHORTCODE_DIR_PATH")){
		define('REJUVE_BITECHX_SHORTCODE_DIR_PATH',plugin_dir_path( __FILE__ ));
	}
	if(!defined("REJUVE_BITECHX_SHORTCODE_DIR_URL")){
		define('REJUVE_BITECHX_SHORTCODE_DIR_URL',plugin_dir_url( __FILE__ ));
	}
	if(!defined("REJUVE_BITECHX_SHORTCODE_DIR_VERSION")){
		define('REJUVE_BITECHX_SHORTCODE_DIR_VERSION',"1.0.0");
	}
	if(!defined("REJUVE_BITECHX_SHORTCODE_DIR_VERSIONEXT")){
		define('REJUVE_BITECHX_SHORTCODE_DIR_VERSIONEXT',"rejuve_btx");
	}
	function test_input($data) {
		  $data = trim($data);
		  $data = stripslashes($data);
		  $data = htmlspecialchars($data);
		  return $data;
	}
	
	
	function TableName_Testimonial()
	 {
		global $wpdb;
		$value = $wpdb->prefix . 'rejuve_db_testimonial' ;
		return $value;
		
	  }
	
	function rejuve_btx_fun_MakeDBForTestimonial()
        {
        		$tablename = TableName_Testimonial();
        		$sql = "CREATE TABLE `".$tablename."` (
                         `id` int(11) NOT NULL AUTO_INCREMENT,
                         `Fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
                         `Date` varchar(255) COLLATE utf8_unicode_ci ,
                         `Location` text COLLATE utf8_unicode_ci,
                         `Testimonial` longtext COLLATE utf8_unicode_ci NOT NULL,
                         `UplodeTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                         PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
        	  require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        	  dbDelta($sql);
        }
	
    	register_activation_hook( __FILE__, 'rejuve_btx_fun_MakeDBForTestimonial');
	
	
	

	
	
	function rejuve_btx_fun_shortcode_menu()
	{
		 include_once REJUVE_BITECHX_SHORTCODE_DIR_PATH."AdminArea/scode_Des_admin.php"; 
	}
	function rejuve_btx_fun_testimonials_menu()
	{
		include_once REJUVE_BITECHX_SHORTCODE_DIR_PATH."AdminArea/testimonials_admin.php"; 
	}
	
	
	function rejuve_btx_fun_menu_admin()
	{
	    add_menu_page(
	        ' Custom Menu ',
	        ' Custom Menu ',
	        'manage_options',
	        'rejuve_btx_shortcode',
	        'rejuve_btx_fun_shortcode_menu',
	         'dashicons-menu',
	        2
	    );
	    
	     add_submenu_page(
			 'rejuve_btx_shortcode',
			 'Wp Short Codes',
			 'Wp Short Codes',
			 'manage_options',
			 'rejuve_btx_shortcode',
			 'rejuve_btx_fun_shortcode_menu'
		);
		add_submenu_page(
			 'rejuve_btx_shortcode',
			 'Testimonials',
			 'Testimonials',
			 'manage_options',
			 'rejuve_btx_testimonials',
			 'rejuve_btx_fun_testimonials_menu'
		);
	}
	add_action('admin_menu', 'rejuve_btx_fun_menu_admin');

	
	



	
	function rejuve_btx_fun_TestimonialUpdateAdmin_handler(){
            global $wpdb;
            
            if($_REQUEST['parem'] == 'TestimonialUpdateAdminAdd_Data'){
                $Fname = test_input($_REQUEST['FirstName']);
                $date = test_input($_REQUEST['GivenDate']);
                $location = test_input($_REQUEST['GivenLocation']);
                $testimonial = test_input($_REQUEST['TestimonialTextarea']);
                
                
                $Db_insert = array(
        		           'Fname'=>$Fname,
        		           'Date'=>$date,
        		           'Location'=>$location,
        		           'Testimonial'=>$testimonial,
        		           
        		    );
                
                $wpdb->insert( TableName_Testimonial(), $Db_insert) or die(json_encode(array("status"=>"error","message"=>"Database Error")));
                echo json_encode(array("status"=>"success","message"=>"Successfully Add Data"));
                
                //print_r($_REQUEST);
            }
            else if($_REQUEST['parem'] == 'TestimonialUpdateAdminedit_Data'){
                $id = $_REQUEST['selectedId'];
                
                
                $value = json_encode($wpdb->get_results( "SELECT * FROM ".TableName_Testimonial() ." where `id`=".$id));
               
                echo json_encode(array("status"=>"success","message"=> $value));
            }
            else if($_REQUEST['parem'] == 'TestimonialUpdateAdminEditAdd_Data_form'){
                $id =  test_input($_REQUEST['IdSelect']);
                $Fname = test_input($_REQUEST['FirstNameEdit']);
                $date = test_input($_REQUEST['GivenDateEdit']);
                $location = test_input($_REQUEST['GivenLocationEdit']);
                $testimonial = test_input($_REQUEST['TestimonialTextareaEdit']);
                
                $Db_update = array(
        		           'Fname'=>$Fname,
        		           'Date'=>$date,
        		           'Location'=>$location,
        		           'Testimonial'=>$testimonial,
        		           
        		    );
                try{
                 $wpdb->update(TableName_Testimonial(), $Db_update , array('id'=>$id)) /*or die(json_encode(array("status"=>"error","message"=>"Database Error")))*/;
}catch(Exception $e){
 echo json_encode(array("status"=>"error","message"=>$e->getMessage()));
}
                 echo json_encode(array("status"=>"success","message"=>"Successfully Add Data"));
              
            }
            else if($_REQUEST['parem'] == 'TestimonialUpdateAdminDelete_Data'){
               $wpdb->delete( TableName_Testimonial(), array( 'id'  => $_REQUEST['DeletedId'] ) );
                echo json_encode(array("status"=>"success","message"=>"Successfully Delete Data"));
            }
    	    
    	     wp_die();
    }
	
    add_action( 'wp_ajax_TestimonialUpdateAdmin', 'rejuve_btx_fun_TestimonialUpdateAdmin_handler' );
	
	
	
	
	
	add_shortcode( "Btx_Show_Testimonial_Main_Page", 'rejuve_btx_fun_Main_Page_Show_Testimonial');
	function rejuve_btx_fun_Main_Page_Show_Testimonial(){
	     include_once REJUVE_BITECHX_SHORTCODE_DIR_PATH."views/Main_Page_testimonial_show.php"; 
	}
       add_shortcode( "Btx_Show_Testimonial_Home_Page", 'rejuve_btx_fun_Home_Page_Show_Testimonial');
	function rejuve_btx_fun_Home_Page_Show_Testimonial(){
	     include_once REJUVE_BITECHX_SHORTCODE_DIR_PATH."views/Home_Page_testimonial_show.php"; 
	}
	
    	