<?php
        ob_start();
        global $wpdb;
        $array = $wpdb->get_results( "SELECT * FROM `".TableName_Testimonial()."` ORDER BY `".TableName_Testimonial()."`.`id` DESC");
       
       
       //print_r($_GET);

       if($_GET['post'] != 2171){
          ?>
          

<!DOCTYPE html>
<head>


        <link rel='stylesheet' type='text/css' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
</head>
<body>	
	<div class ='container' style="padding-top:80px;">
	    
	    <?php
	    
	    if(count($array) >= 1){
	        $it = 1;
	        foreach($array as $value){
	            if($it%2 != 0){
	                ?>
	                
                    	<div class="row">
                			<div class='col-md-6 order-1 order-md-0 text-md-right text-left'>
                				<p style="">" <?php echo $value->Testimonial ?> "</p>
        				        <p style="font-size:0.88em;">-<?php echo $value->Fname ?> <?php echo $value->Date ?></p>
                			</div>
                			<div class='col-md-6 text-md-left text-center' style="justify-content: left; padding-bottom: 30px;">
                				<img style="height:200px;object-fit: cover;max-width: 100%;"  src="https://www.rejuvesthetics.com/wp-content/uploads/2019/03/2-01.svg">
                			</div>
                    			
                    	</div>
	                
	                <?php
	            }
	            else {
	                
	                ?>
	                
	                
	                	<div class="row" style="margin-top: 40px;">
                			<div class='col-md-6 text-md-right text-center' style="justify-content: right; padding-bottom: 30px;">
                				<img style="height:200px;object-fit: cover;max-width: 100%;"  src="https://www.rejuvesthetics.com/wp-content/uploads/2019/03/1-01.svg">
                			</div>
                			<div class='col-md-6'>
                				<p>"<?php echo $value->Testimonial ?> "</p>
                				<p style="font-size:0.88em;">-<?php echo $value->Fname ?> <?php echo $value->Date ?></p>
                			</div>
                		</div>
	                
	                
	                <?php
	                
	            }
	            $it++;
	        }
	        
	    }else{
	        ?>
	        
	        No Testimonial Found
	        
	        <?php
	      
	    }
	    
	    ?>
	    
	
	

	</div>
	</body>
</html>

<?php
       }
        ?>